#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan
import random
import tf
import math

things_ahead = False
callback_msg = None
forward_range = None
odom_msg = None
def odom_callback(msg2):
   global odom_msg
   odom_msg = msg2.pose
   #print callback_msg.pose
moving_forward = True
def callback(msg):
    global forward_range
    forward_range = msg.ranges[:30] + msg.ranges[330:]
    global callback_msg
    callback_msg = msg
    global things_ahead
    things_ahead = False
    global moving_forward
    moving_forward = True
    for value in forward_range:
        if value != 'inf':
            if value < .5:
                things_ahead = True
                #print value
    if things_ahead:
        moving_forward = False
    else:
        moving_forward = True


scanner_sub = rospy.Subscriber('/scan', LaserScan, callback)
direction_pub = rospy.Publisher('/cmd_vel', Twist, queue_size = 10)

rospy.init_node('wander')

rate = rospy.Rate(2)
while not rospy.is_shutdown():
    t = Twist()
    if forward_range == None or callback_msg == None:
        print 'waiting for ranges and callback to be something'
    else:
        if moving_forward:
            t.linear.x = .1
            t.angular.z = 0
        else:
            t.linear.x = 0
            t.angular.z = .2
    direction_pub.publish(t)
    rate.sleep()
